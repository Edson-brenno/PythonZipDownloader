namespace ScreenSound.Interfaces.MenuInterface{
    internal interface IMenu{
        void ShowTheChoosedMenuOption();
    }
}