﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ScreenSound2._0.Migrations
{
    /// <inheritdoc />
    public partial class AddRelationOneToManyFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
